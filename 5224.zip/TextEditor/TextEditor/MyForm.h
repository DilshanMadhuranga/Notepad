#pragma once

namespace TextEditor {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	protected:
	private: System::Windows::Forms::ToolStripMenuItem^ fileToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ newToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ openToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ saveToolStripMenuItem;
	private: System::Windows::Forms::ToolStripSeparator^ toolStripSeparator1;
	private: System::Windows::Forms::ToolStripMenuItem^ exitToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ editToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ fontToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ fontColorToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ backgroundColorToolStripMenuItem;

	private: System::Windows::Forms::FontDialog^ fontDialog1;
	private: System::Windows::Forms::ColorDialog^ colorDialog1;
	private: System::Windows::Forms::OpenFileDialog^ openFileDialog1;
	private: System::Windows::Forms::SaveFileDialog^ saveFileDialog1;

	private: System::Windows::Forms::ColorDialog^ colorDialog2;
	private: System::Windows::Forms::RichTextBox^ richTextBox1;
	private: System::Windows::Forms::ToolStripSeparator^ toolStripSeparator2;
	private: System::Windows::Forms::ToolStripMenuItem^ cutToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ copyToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ pastToolStripMenuItem;



	private: System::Windows::Forms::ToolStripSeparator^ toolStripSeparator3;


	private: System::Windows::Forms::ToolStripMenuItem^ saveAsToolStripMenuItem;


	private: System::Windows::Forms::PrintDialog^ printDialog1;













	private: System::ComponentModel::IContainer^ components;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->newToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveAsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator1 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->editToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->fontToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->fontColorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->backgroundColorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator2 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->cutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->copyToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->pastToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator3 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->fontDialog1 = (gcnew System::Windows::Forms::FontDialog());
			this->colorDialog1 = (gcnew System::Windows::Forms::ColorDialog());
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
			this->colorDialog2 = (gcnew System::Windows::Forms::ColorDialog());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->printDialog1 = (gcnew System::Windows::Forms::PrintDialog());
			this->menuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->BackColor = System::Drawing::Color::WhiteSmoke;
			this->menuStrip1->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->menuStrip1->ImageScalingSize = System::Drawing::Size(20, 20);
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {
				this->fileToolStripMenuItem,
					this->editToolStripMenuItem
			});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(822, 31);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			this->menuStrip1->ItemClicked += gcnew System::Windows::Forms::ToolStripItemClickedEventHandler(this, &MyForm::menuStrip1_ItemClicked);
			// 
			// fileToolStripMenuItem
			// 
			this->fileToolStripMenuItem->BackColor = System::Drawing::Color::Transparent;
			this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(6) {
				this->newToolStripMenuItem,
					this->openToolStripMenuItem, this->saveToolStripMenuItem, this->saveAsToolStripMenuItem, this->toolStripSeparator1, this->exitToolStripMenuItem
			});
			this->fileToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Nirmala UI", 10.2F));
			this->fileToolStripMenuItem->ImageTransparentColor = System::Drawing::Color::Transparent;
			this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
			this->fileToolStripMenuItem->Padding = System::Windows::Forms::Padding(10, 0, 10, 0);
			this->fileToolStripMenuItem->Size = System::Drawing::Size(59, 27);
			this->fileToolStripMenuItem->Text = L"&File";
			// 
			// newToolStripMenuItem
			// 
			this->newToolStripMenuItem->Name = L"newToolStripMenuItem";
			this->newToolStripMenuItem->Padding = System::Windows::Forms::Padding(0, 5, 0, 5);
			this->newToolStripMenuItem->Size = System::Drawing::Size(224, 36);
			this->newToolStripMenuItem->Text = L"&New";
			this->newToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::newToolStripMenuItem_Click);
			// 
			// openToolStripMenuItem
			// 
			this->openToolStripMenuItem->Name = L"openToolStripMenuItem";
			this->openToolStripMenuItem->Padding = System::Windows::Forms::Padding(0, 5, 0, 5);
			this->openToolStripMenuItem->Size = System::Drawing::Size(224, 36);
			this->openToolStripMenuItem->Text = L"&Open";
			this->openToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::openToolStripMenuItem_Click);
			// 
			// saveToolStripMenuItem
			// 
			this->saveToolStripMenuItem->Name = L"saveToolStripMenuItem";
			this->saveToolStripMenuItem->Padding = System::Windows::Forms::Padding(0, 5, 0, 5);
			this->saveToolStripMenuItem->Size = System::Drawing::Size(224, 36);
			this->saveToolStripMenuItem->Text = L"&Save";
			this->saveToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::saveToolStripMenuItem_Click);
			// 
			// saveAsToolStripMenuItem
			// 
			this->saveAsToolStripMenuItem->Name = L"saveAsToolStripMenuItem";
			this->saveAsToolStripMenuItem->Padding = System::Windows::Forms::Padding(0, 5, 0, 5);
			this->saveAsToolStripMenuItem->Size = System::Drawing::Size(224, 36);
			this->saveAsToolStripMenuItem->Text = L"Save As";
			this->saveAsToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::saveAsToolStripMenuItem_Click);
			// 
			// toolStripSeparator1
			// 
			this->toolStripSeparator1->Name = L"toolStripSeparator1";
			this->toolStripSeparator1->Size = System::Drawing::Size(221, 6);
			// 
			// exitToolStripMenuItem
			// 
			this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
			this->exitToolStripMenuItem->Padding = System::Windows::Forms::Padding(0, 5, 0, 5);
			this->exitToolStripMenuItem->Size = System::Drawing::Size(224, 36);
			this->exitToolStripMenuItem->Text = L"&Exit";
			this->exitToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::exitToolStripMenuItem_Click);
			// 
			// editToolStripMenuItem
			// 
			this->editToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(8) {
				this->fontToolStripMenuItem,
					this->fontColorToolStripMenuItem, this->backgroundColorToolStripMenuItem, this->toolStripSeparator2, this->cutToolStripMenuItem,
					this->copyToolStripMenuItem, this->pastToolStripMenuItem, this->toolStripSeparator3
			});
			this->editToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Nirmala UI", 10.2F));
			this->editToolStripMenuItem->Name = L"editToolStripMenuItem";
			this->editToolStripMenuItem->Padding = System::Windows::Forms::Padding(10, 0, 10, 0);
			this->editToolStripMenuItem->Size = System::Drawing::Size(63, 27);
			this->editToolStripMenuItem->Text = L"&Edit";
			// 
			// fontToolStripMenuItem
			// 
			this->fontToolStripMenuItem->Name = L"fontToolStripMenuItem";
			this->fontToolStripMenuItem->Padding = System::Windows::Forms::Padding(0, 5, 0, 5);
			this->fontToolStripMenuItem->Size = System::Drawing::Size(231, 36);
			this->fontToolStripMenuItem->Text = L"&Font";
			this->fontToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::fontToolStripMenuItem_Click);
			// 
			// fontColorToolStripMenuItem
			// 
			this->fontColorToolStripMenuItem->Name = L"fontColorToolStripMenuItem";
			this->fontColorToolStripMenuItem->Padding = System::Windows::Forms::Padding(0, 5, 0, 5);
			this->fontColorToolStripMenuItem->Size = System::Drawing::Size(231, 36);
			this->fontColorToolStripMenuItem->Text = L"Font &Color";
			this->fontColorToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::fontColorToolStripMenuItem_Click);
			// 
			// backgroundColorToolStripMenuItem
			// 
			this->backgroundColorToolStripMenuItem->Name = L"backgroundColorToolStripMenuItem";
			this->backgroundColorToolStripMenuItem->Padding = System::Windows::Forms::Padding(0, 5, 0, 5);
			this->backgroundColorToolStripMenuItem->Size = System::Drawing::Size(231, 36);
			this->backgroundColorToolStripMenuItem->Text = L"&Background Color";
			this->backgroundColorToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::backgroundColorToolStripMenuItem_Click);
			// 
			// toolStripSeparator2
			// 
			this->toolStripSeparator2->Name = L"toolStripSeparator2";
			this->toolStripSeparator2->Size = System::Drawing::Size(228, 6);
			// 
			// cutToolStripMenuItem
			// 
			this->cutToolStripMenuItem->Margin = System::Windows::Forms::Padding(5, 10, 0, 0);
			this->cutToolStripMenuItem->Name = L"cutToolStripMenuItem";
			this->cutToolStripMenuItem->Padding = System::Windows::Forms::Padding(0);
			this->cutToolStripMenuItem->Size = System::Drawing::Size(231, 26);
			this->cutToolStripMenuItem->Text = L"&Cut";
			this->cutToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::cutToolStripMenuItem_Click);
			// 
			// copyToolStripMenuItem
			// 
			this->copyToolStripMenuItem->Margin = System::Windows::Forms::Padding(5, 10, 0, 0);
			this->copyToolStripMenuItem->Name = L"copyToolStripMenuItem";
			this->copyToolStripMenuItem->Padding = System::Windows::Forms::Padding(0);
			this->copyToolStripMenuItem->Size = System::Drawing::Size(231, 26);
			this->copyToolStripMenuItem->Text = L"&Copy";
			this->copyToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::copyToolStripMenuItem_Click);
			// 
			// pastToolStripMenuItem
			// 
			this->pastToolStripMenuItem->Margin = System::Windows::Forms::Padding(5, 10, 0, 0);
			this->pastToolStripMenuItem->Name = L"pastToolStripMenuItem";
			this->pastToolStripMenuItem->Padding = System::Windows::Forms::Padding(0);
			this->pastToolStripMenuItem->Size = System::Drawing::Size(231, 26);
			this->pastToolStripMenuItem->Text = L"&Paste";
			this->pastToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::pastToolStripMenuItem_Click);
			// 
			// toolStripSeparator3
			// 
			this->toolStripSeparator3->Name = L"toolStripSeparator3";
			this->toolStripSeparator3->Size = System::Drawing::Size(228, 6);
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->Filter = L"txt files (.txt)|.txt|All files (.)|.";
			this->openFileDialog1->InitialDirectory = L"c:\\\\";
			this->openFileDialog1->RestoreDirectory = true;
			// 
			// saveFileDialog1
			// 
			this->saveFileDialog1->Filter = L"txt files (.txt)|.txt|All files (.)|.";
			this->saveFileDialog1->RestoreDirectory = true;
			// 
			// richTextBox1
			// 
			this->richTextBox1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->richTextBox1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->richTextBox1->Location = System::Drawing::Point(0, 31);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(822, 363);
			this->richTextBox1->TabIndex = 2;
			this->richTextBox1->Text = L"";
			this->richTextBox1->TextChanged += gcnew System::EventHandler(this, &MyForm::richTextBox1_TextChanged);
			this->richTextBox1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &MyForm::richTextBox1_KeyPress);
			// 
			// printDialog1
			// 
			this->printDialog1->UseEXDialog = true;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(822, 394);
			this->Controls->Add(this->richTextBox1);
			this->Controls->Add(this->menuStrip1);
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"MyForm";
			this->Text = L"TextEditor";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void newToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		richTextBox1->Text = "";
	}
	private: System::Void exitToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		Application::Exit();
	}
	private: System::Void fontToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		if (fontDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			richTextBox1->Font = fontDialog1->Font;
		}
	}
	private: System::Void fontColorToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		if (colorDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			richTextBox1->ForeColor = colorDialog1->Color;
		}
	}
	private: System::Void backgroundColorToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		if (colorDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			richTextBox1->BackColor = colorDialog1->Color;
		}
	}
	private: System::Void openToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			StreamReader^ sr = gcnew StreamReader(openFileDialog1->FileName);
			richTextBox1->Text = sr->ReadToEnd();
			sr->Close();
		}
	}
	private: System::Void saveToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			StreamWriter^ sw = gcnew StreamWriter(saveFileDialog1->FileName);
			sw->Write(richTextBox1->Text);
			sw->Close();
		}
	}
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {

	}
	private: System::Void richTextBox1_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {

		

			// Check if the pressed key is a letter
		if (Char::IsLetter(e->KeyChar)) {
			// If it's the first character or the previous character is a newline or period
			if (richTextBox1->Text->Length == 0 || richTextBox1->SelectionStart == 0 ||
				richTextBox1->Text[richTextBox1->SelectionStart - 1] == '\n' ||
				richTextBox1->Text[richTextBox1->SelectionStart - 1] == '.') {
				// Capitalize the letter
				e->KeyChar = Char::ToUpper(e->KeyChar);
			}
		}

		

		int cursorPosition = richTextBox1->SelectionStart;
		String^ inputText = richTextBox1->Text;

		

			// Capitalize the first letter of each sentence
			bool capitalizeNextLetter = true;
			for (int i = 0; i < inputText->Length; ++i) {
				if (capitalizeNextLetter && Char::IsLetter(inputText[i])) {
					inputText = inputText->Substring(0, i) + Char::ToUpper(inputText[i]) + inputText->Substring(i + 1);
					capitalizeNextLetter = false;
				}

				if (inputText[i] == '.') {
					capitalizeNextLetter = true;
				}
			}

			richTextBox1->Text = inputText;

		

		// Reset the font style for the entire text
		richTextBox1->SelectionStart = 0;
		richTextBox1->SelectionLength = richTextBox1->Text->Length;
		richTextBox1->SelectionFont = gcnew System::Drawing::Font(richTextBox1->Font, FontStyle::Regular);
		richTextBox1->SelectionColor = Color::Black; // Reset text color
		richTextBox1->SelectionLength = 0;

		// Find and underline areas around double spaces
		int startIndex = 0;
		while (startIndex < richTextBox1->Text->Length) {
			int doubleSpaceIndex = richTextBox1->Text->IndexOf("  ", startIndex);
			if (doubleSpaceIndex != -1) {
				// Reset formatting for characters before the double space
				int resetBeforeIndex = doubleSpaceIndex > 0 ? doubleSpaceIndex - 1 : 0;
				richTextBox1->SelectionStart = resetBeforeIndex;
				richTextBox1->SelectionLength = 1;
				richTextBox1->SelectionFont = gcnew System::Drawing::Font(richTextBox1->Font, FontStyle::Regular);
				richTextBox1->SelectionColor = Color::Black; // Reset text color
				richTextBox1->SelectionLength = 0;

				// Underline the area around the double space
				int startUnderline = doubleSpaceIndex;
				int lengthUnderline = 2;

				richTextBox1->SelectionStart = startUnderline;
				richTextBox1->SelectionLength = lengthUnderline;
				richTextBox1->SelectionFont = gcnew System::Drawing::Font(richTextBox1->Font, FontStyle::Underline | FontStyle::Bold); // Underline and make it bold
				richTextBox1->SelectionColor = Color::Red; // Set text color to red
				richTextBox1->SelectionLength = 0;

				// Reset formatting for characters after the double space
				int resetAfterIndex = doubleSpaceIndex + 2;
				if (resetAfterIndex < richTextBox1->Text->Length) {
					richTextBox1->SelectionStart = resetAfterIndex;
					richTextBox1->SelectionLength = 1;
					richTextBox1->SelectionFont = gcnew System::Drawing::Font(richTextBox1->Font, FontStyle::Regular);
					richTextBox1->SelectionColor = Color::Black; // Reset text color
					richTextBox1->SelectionLength = 0;
				}

				startIndex = resetAfterIndex;  // Move to the next position after the double space
			}
			else {
				break;  // No more double spaces found
			}
		}

		// Check for full stops without a single space following them
		for (int i = 0; i < richTextBox1->Text->Length - 1; ++i) {
			if (richTextBox1->Text[i] == '.') {
				// Check if there is no space immediately after the period
				if (i + 1 >= richTextBox1->Text->Length || richTextBox1->Text[i + 1] != ' ') {
					// Underline the area around the full stop in red
					richTextBox1->SelectionStart = i;
					richTextBox1->SelectionLength = 1;
					richTextBox1->SelectionFont = gcnew System::Drawing::Font(richTextBox1->Font, FontStyle::Underline | FontStyle::Bold); // Underline and make it bold
					richTextBox1->SelectionColor = Color::Red; // Set text color to red
					richTextBox1->SelectionLength = 0;
				}
			}
		}
		// Set the cursor position to the original position or the end of the text
		richTextBox1->SelectionStart = Math::Min(cursorPosition, richTextBox1->Text->Length);

	}



	private: System::Void cutToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		richTextBox1->Cut();
	}
	private: System::Void copyToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		richTextBox1->Copy();
	}
	private: System::Void pastToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		richTextBox1->Paste();
	}
	
	private: System::Void saveAsToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			StreamWriter^ sw = gcnew StreamWriter(saveFileDialog1->FileName);
			sw->Write(richTextBox1->Text);
			sw->Close();
		}
	}

	private: System::Void fileToolStripMenuItem_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
	}
	private: System::Void richTextBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void fileToolStripMenuItem_MouseEnter(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void menuStrip1_ItemClicked(System::Object^ sender, System::Windows::Forms::ToolStripItemClickedEventArgs^ e) {
	}
};
}